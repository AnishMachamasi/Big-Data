# Define a simple Python function to print a message
def print_hello():
    print("Hello, this is a sample Python job!")